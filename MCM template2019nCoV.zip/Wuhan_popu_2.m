N=[0,14000000];
u=readmatrix('D:\\abc.xlsx','Sheet','Sheet1','Range',[12 3 33 4]);
v=u(:,2);
u=u(:,1);
for i=1:length(u)
    temp=((u(i)-v(i))/100+1)*N(i,2);
    N=[N;i,temp];
end
stem(N(:,1),N(:,2));
xlabel('t'),ylabel('Total Population');